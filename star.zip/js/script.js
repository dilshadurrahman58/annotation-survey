// Define the toggleDiv function
function toggleDiv(button, abstractDiv) {
    let contentDiv = document.getElementById(abstractDiv);
    let buttonElem = document.getElementById(button);
    if (contentDiv.style.display === "none" || contentDiv.style.display === "") {
        buttonElem.innerHTML = "▼";
        contentDiv.style.display = "block";
    } else {
        buttonElem.innerHTML = "►";
        contentDiv.style.display = "none";
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const url = 'https://docs.google.com/spreadsheets/d/e/2PACX-1vSDf3Uc4wp0I_O-uZ_mDCOmHAaktsU7MXdw6VpvN8im_5XDN_rmShVYhuAbJbQLj2fUBjmjmxjKmIjP/pub?gid=1840793528&single=true&output=csv';

    const cardsContainer = document.getElementById('cards-container');
    const venueFilterContainer = document.getElementById('venue-filter-container');
    const otherFiltersContainer = document.getElementById('other-filters-container');
    const searchBar = document.getElementById('search-bar');
    const totalPapersSpan = document.getElementById('total-papers');
    // const yearSlider = document.getElementById('year-slider');
    // const yearRangeLabel = document.getElementById('year-range-label');
    const darkModeToggle = document.getElementById('dark-mode-toggle');

    // Add event listeners for Annotation Types checkboxes
    const textualCheckbox = document.getElementById("textual-checkbox");
    const graphicalCheckbox = document.getElementById("graphical-checkbox");

    textualCheckbox.addEventListener("change", filterCards);
    graphicalCheckbox.addEventListener("change", filterCards);


    const manualCheckbox = document.getElementById("manual-checkbox");
    const automaticCheckbox = document.getElementById("automatic-checkbox");
    const semiAutomaticCheckbox = document.getElementById("semi-automatic-checkbox");

    manualCheckbox.addEventListener("change", filterCards);
    automaticCheckbox.addEventListener("change", filterCards);
    semiAutomaticCheckbox.addEventListener("change", filterCards);



    

    // Load sound effects
    const clickSound = new Audio('sounds/click.mp3');
    const modalOpenSound = new Audio('sounds/modal-open.mp3');
    const filterSelectSound = new Audio('sounds/filter-select.mp3');

    const otherFields = ["Empirical Study", "Tool, Technique, and Framework", "Storytelling and Narrative Visualizations",
        "Collaborative Sensemaking and Data Analysis", "Exploratory Data Analysis", "Provenance", "Uncertainty Visualization", "Interaction and User Engagement"
    ];
    const alwaysShowFields = [
        "Annotation Types", "Annotation Subcategories", "Annotation Generation Method"
    ];
    let otherVenues = [];
    let data = []; // Global variable to store parsed data
    let filteredData = []; // Global variable to store filtered data

    // Initialize the chart with interactive tooltips
    const ctx = document.getElementById('papers-chart').getContext('2d');
    let papersChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Number of Papers',
                data: [],
                borderColor: '#0056b3',
                backgroundColor: 'rgba(0, 86, 179, 0.2)',
                tension: 0.3,
                pointRadius: 4,
                pointBackgroundColor: '#ffffff',
                borderWidth: 1.5,
                pointBorderWidth: 1,
                pointHoverRadius: 6,
                pointHoverBackgroundColor: '#0056b3'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: {
                    title: {
                        display: true,
                        text: 'Year',
                        font: {
                            size: 9,
                            family: 'Arial, sans-serif',
                            weight: 'bold',
                            color: '#333'
                        }
                    },
                    ticks: {
                        maxRotation: 45,
                        minRotation: 0,
                        font: {
                            size: 7,
                            family: 'Arial, sans-serif',
                            color: '#555'
                        },
                        padding: 5
                    },
                    grid: {
                        color: 'rgba(200, 200, 200, 0.3)',
                        borderDash: [5, 5]
                    }
                },
                y: {
                    title: {
                        display: true,
                        text: 'Number of Papers',
                        font: {
                            size: 9,
                            family: 'Arial, sans-serif',
                            weight: 'bold',
                            color: '#333'
                        }
                    },
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1,
                        font: {
                            size: 7,
                            family: 'Arial, sans-serif',
                            color: '#555'
                        },
                        padding: 5
                    },
                    grid: {
                        color: 'rgba(200, 200, 200, 0.3)',
                        borderDash: [5, 5]
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 86, 179, 0.8)',
                    titleFont: {
                        size: 10,
                        family: 'Arial, sans-serif',
                        weight: 'bold'
                    },
                    bodyFont: {
                        size: 9,
                        family: 'Arial, sans-serif'
                    },
                    padding: 8,
                    callbacks: {
                        label: function (context) {
                            // Custom tooltip showing the count and a specific note
                            return `Year: ${context.label}, Papers: ${context.raw}`;
                        }
                    }
                }
            }
        }
    });

    // Parse the CSV data from the URL
    Papa.parse(url, {
        download: true,
        header: true,
        skipEmptyLines: false,
        complete: function (results) {
            data = results.data;
            const records = results.data;
            if (records.length === 0) {
                console.error('No data found in the CSV file.');
                return;
            }
            const venues = getUniqueVenues(records);
            generateVenueFilters(venues);
            generateOtherFilters(records);
            renderCards(records);
            updateChart(records);

            // Event listeners for filtering
            venueFilterContainer.addEventListener('change', filterCards);
            otherFiltersContainer.addEventListener('change', filterCards);
            searchBar.addEventListener('input', filterCards);

            // Handle slider change
            // yearSlider.addEventListener('input', handleYearSliderChange);

            // Select All functionality
            document.getElementById('select-all-venues').addEventListener('click', () => {
                toggleSelectAll('venue-checkbox');
                //playSound(filterSelectSound);
            });
            document.getElementById('select-all-types').addEventListener('click', () => {
                toggleSelectAll('other-checkbox');
                //playSound(filterSelectSound);
            });
            // Add event listener for the "Select All" / "Deselect All" button for Annotation Types
            document.getElementById('select-all-annotation-types').addEventListener('click', function () {
                toggleSelectAll(this, 'annotation-checkbox'); // Target 'annotation-checkbox' class
            });


            // Handle dark mode toggle with smooth transition and tooltips
            darkModeToggle.addEventListener('change', toggleDarkMode);
            darkModeToggle.title = darkModeToggle.checked ? "Switch to Light Mode" : "Switch to Dark Mode"; // Set initial tooltip
        },
        error: function (error) {
            console.error('Error parsing CSV:', error);
        }
    });

    // Handle year slider change
    // function handleYearSliderChange() {
    //     const maxYear = parseInt(yearSlider.value);
    //     yearRangeLabel.textContent = `1994 - ${maxYear}`;
    //     filterCards();
    // }

    const yearMinLabel = document.getElementById('year-min');
    const yearMaxLabel = document.getElementById('year-max');

    // Initialize noUiSlider for range selection
    noUiSlider.create(document.getElementById('year-range-slider'), {
        start: [1994, 2024], // Starting range for the slider
        connect: true,
        range: {
            'min': 1994,
            'max': 2024
        },
        step: 1,
        tooltips: [false, false], // Optional: Tooltips on the handles
        format: {
            to: value => Math.round(value), // Display rounded year values
            from: value => Number(value)
        }
    });

    // Update the labels and filter the data when the slider values change
    document.getElementById('year-range-slider').noUiSlider.on('update', function (values) {
        const minYear = Math.round(values[0]);
        const maxYear = Math.round(values[1]);

        // Update the display to show selected range
        yearMinLabel.textContent = minYear;
        yearMaxLabel.textContent = maxYear;

        // Call filterCards function to update the displayed data
        filterCards();
    });

    // Function to toggle checkboxes and update the button text
    function toggleSelectAll(button, className) {
        const checkboxes = document.querySelectorAll(`.${className}`);
        const allChecked = Array.from(checkboxes).every(cb => cb.checked);
        const someChecked = Array.from(checkboxes).some(cb => cb.checked);

        // If any checkbox is checked, toggle all to unchecked
        if (someChecked) {
            checkboxes.forEach(cb => cb.checked = false);
            button.textContent = "Select All";
            button.classList.remove('active');
        } else {
            // If none are checked, toggle all to checked
            checkboxes.forEach(cb => cb.checked = true);
            button.textContent = "Deselect All";
            button.classList.add('active');
        }

        filterCards(); // Update displayed data based on the checkbox state
    }

    // Add event listeners for the "Select All" / "Deselect All" buttons
    document.getElementById('select-all-venues').addEventListener('click', function () {
        toggleSelectAll(this, 'venue-checkbox');
    });

    document.getElementById('select-all-types').addEventListener('click', function () {
        toggleSelectAll(this, 'other-checkbox');
    });

    // Update button state based on manual checkbox changes
    document.getElementById('venue-filter-container').addEventListener('change', () => {
        updateButtonState('select-all-venues', 'venue-checkbox');
        playSound(filterSelectSound);
    });

    document.getElementById('other-filters-container').addEventListener('change', () => {
        updateButtonState('select-all-types', 'other-checkbox');
        playSound(filterSelectSound);
    });

    // Update button state when checkboxes are changed manually
    document.getElementById('annotation-filter-container').addEventListener('change', () => {
        updateButtonState('select-all-annotation-types', 'annotation-checkbox');
        playSound(filterSelectSound);
    });

    document.getElementById('select-all-annotation-generation').addEventListener('click', function () {
        toggleSelectAll(this, 'annotation-generation-checkbox'); // Target 'annotation-generation-checkbox' class
    });




    // Function to update the button text based on the checkbox state
    function updateButtonState(buttonId, className) {
        const button = document.getElementById(buttonId);
        const checkboxes = document.querySelectorAll(`.${className}`);
        const someChecked = Array.from(checkboxes).some(cb => cb.checked);

        button.textContent = someChecked ? "Deselect All" : "Select All";
        if (someChecked) {
            button.classList.add('active');
        } else {
            button.classList.remove('active');
        }
    }

    // Get unique venues from records
    function getUniqueVenues(records) {
        const venueCounts = {};

        records.forEach(record => {
            const venue = record['Venue'];
            if (venue) {
                if (!venueCounts[venue]) {
                    venueCounts[venue] = 0;
                }
                venueCounts[venue]++;
            }
        });

        const venues = [];
        let otherCount = 0;

        Object.keys(venueCounts).forEach(venue => {
            if (venueCounts[venue] >= 5) {
                venues.push({ venue, count: venueCounts[venue] });
            } else {
                otherVenues.push(venue);
                otherCount += venueCounts[venue];
            }
        });

        venues.sort((a, b) => b.count - a.count);

        if (otherCount > 0) {
            venues.push({ venue: 'Other', count: otherCount });
        }

        return venues;
    }

    // Generate filters for venues
    function generateVenueFilters(venues) {
        venues.forEach(({ venue, count }) => {
            const label = document.createElement('label');
            label.className = 'venue-filter';
            label.innerHTML = `
                <input type="checkbox" class="venue-checkbox" value="${venue}" checked>
                ${venue} (${count})
            `;
            venueFilterContainer.appendChild(label);
        });
    }

    // Generate filters for other fields
    function generateOtherFilters(records) {
        const otherCounts = {};

        records.forEach(record => {
            otherFields.forEach(field => {
                if (record[field] === 'X') {
                    if (!otherCounts[field]) {
                        otherCounts[field] = 0;
                    }
                    otherCounts[field]++;
                }
            });
        });

        otherFields.forEach(field => {
            const label = document.createElement('label');
            label.className = 'other-filter';
            label.innerHTML = `
                <input type="checkbox" class="other-checkbox" value="${field}" checked>
                ${field} (${otherCounts[field]})
            `;
            otherFiltersContainer.appendChild(label);
        });
    }

    // Define the fields to include in the CSV
    const requiredFields = ["Title", "Venue", "Year", "Authors", "BibTex"];

    // Function to download filtered data as CSV
    function downloadCSV(records) {
        if (records.length === 0) {
            alert("No data available to download.");
            return;
        }

        // Extract only the required fields from each record
        const csvContent = [
            requiredFields.join(","), // Header row
            ...records.map(record =>
                requiredFields.map(field => `"${record[field] || ''}"`).join(",") // Add each row with the required fields
            )
        ].join("\n");

        const blob = new Blob([csvContent], { type: "text/csv" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "filtered_papers.csv";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    // Add event listener to the download button
    document.getElementById("download-csv-button").addEventListener("click", () => {
        downloadCSV(filteredData); // Use the globally stored filtered data
        playSound(clickSound);
    });

    // Render cards with content based on the records
    function renderCards(records) {
        cardsContainer.innerHTML = ''; // Clear previous cards
        records.forEach((record, idx) => {
            const card = document.createElement('div');
            card.className = 'card card-animated'; // Add animated class for CSS animation
            card.innerHTML = generateCardContent(record, idx);
            cardsContainer.appendChild(card);

            // Attach event listener to the toggle button
            const button = card.querySelector('.triangle-button');
            const abstractDiv = card.querySelector('.abstract-div');
            if (button && abstractDiv) {
                button.addEventListener('click', () => toggleDiv(button.id, abstractDiv.id));
            }

            // Attach event listener to the card image for modal display
            const cardImage = card.querySelector('.card-image');
            if (cardImage) {
                cardImage.addEventListener('click', () => {
                    openModal(record);
                    playSound(modalOpenSound);
                });
            }
        });
        totalPapersSpan.textContent = records.length; // Update total papers count
        updateChart(records); // Update chart data
    }

    // Generate card content dynamically with search term highlighting
    function generateCardContent(record, idx) {
        let content = '';
        content += `<img src="thumbnails/${record['Paper Identifier']}.png" alt="Paper Image" class="card-image" width="100%"/>`;
        content += `<h3>${highlightSearchTerm(record['Title'])}</h3>`;
    
        // Grouping Authors, Annotation Types, and Annotation Generation Method
        content += `<div class="card-details">`;
        content += `<p><strong>Authors:</strong> ${highlightSearchTerm(record['Authors'])}</p>`;
        
        if (record['Venue']) {
            content += `<p><strong>Venue:</strong> ${highlightSearchTerm(record['Venue'])}</p>`;
        }

        if (record['Annotation Types']) {
            content += `<p><strong>Annotation Types:</strong> ${highlightSearchTerm(record['Annotation Types'])}</p>`;
        }
    
        if (record['Annotation Generation Method']) {
            content += `<p><strong>Annotation Generation Method:</strong> ${highlightSearchTerm(record['Annotation Generation Method'])}</p>`;
        }
    
        // Add DOI if present
        if (record['DOI']) {
            content += `<p><strong>DOI:</strong> <a href="https://doi.org/${record['DOI']}" target="_blank">${record['DOI']}</a></p>`;
        }
    
        content += `</div>`;
    
        let tags = '';
        otherFields.forEach(field => {
            if (record[field] === 'X') {
                tags += `<span class="tag">${field}</span> `;
            }
        });
    
        if (tags) {
            content += `<p><strong>Tags:</strong> ${tags}</p>`;
        }
    
        content += `<p><strong>Abstract</strong> `;
        content += `<span class="triangle-button" id="abstractButton-${idx}" style="cursor: pointer;">►</span>`;
        content += `</p>`;
        content += `<div class="abstract-div" id="abstractDiv-${idx}" style="display: none;">${highlightSearchTerm(record['Abstract'])}</div>`;
    
        // Link the PDF icon to the DOI if available
        if (record['DOI']) {
            content += `<a href="https://doi.org/${record['DOI']}" target="_blank"><img src="images/pdf_icon.svg" class="pdf-img" alt="PDF"/></a>`;
        } else {
            content += `<img src="images/pdf_icon.svg" class="pdf-img" alt="PDF"/>`;
        }
    
        if (record['BibTex']) {
            content += `<img src="images/bibtex_icon.png" onclick="downloadBibtex('${idx}')" class="bib-img"/>`;
        }
    
        return content;
    }
    
    
    

    // Function to open a modal with a larger image and detailed information
    function openModal(record) {
        // Create modal elements
        const modal = document.createElement('div');
        modal.className = 'modal';

        const modalContent = document.createElement('div');
        modalContent.className = 'modal-content';

        const modalImage = document.createElement('img');
        modalImage.src = `thumbnails/${record['Paper Identifier']}.png`;
        modalImage.className = 'modal-image';

        const modalTitle = document.createElement('h3');
        modalTitle.textContent = record['Title'];

        const modalAbstract = document.createElement('p');
        modalAbstract.innerHTML = `<strong>Abstract:</strong> ${record['Abstract']}`;

        const closeButton = document.createElement('span');
        closeButton.className = 'close-button';
        closeButton.innerHTML = '&times;';
        closeButton.onclick = () => document.body.removeChild(modal); // Close the modal

        // Append elements to modal
        modalContent.appendChild(closeButton);
        modalContent.appendChild(modalImage);
        modalContent.appendChild(modalTitle);
        modalContent.appendChild(modalAbstract);
        modal.appendChild(modalContent);
        document.body.appendChild(modal);
    }

    // Function to highlight search terms within the text
    function highlightSearchTerm(text) {
        const searchQuery = searchBar.value.toLowerCase();
        if (!searchQuery) return text;

        const regex = new RegExp(`(${searchQuery})`, 'gi');
        return text.replace(regex, '<mark>$1</mark>');
    }

    // Function to update the chart data based on current records
    function updateChart(records) {
        const yearCounts = {};
        records.forEach(record => {
            const year = record['Year'];
            if (year) {
                yearCounts[year] = (yearCounts[year] || 0) + 1;
            }
        });

        const years = Object.keys(yearCounts).sort();
        const counts = years.map(year => yearCounts[year]);

        papersChart.data.labels = years;
        papersChart.data.datasets[0].data = counts;
        papersChart.update();
    }

    // Function to download BibTeX file
    window.downloadBibtex = function (idx) {
        const bibtex = data[idx]['BibTex'];
        const paperId = data[idx]['Paper Identifier'];
        const blob = new Blob([bibtex], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${paperId}.bib`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };
    function filterCards() {
        const checkedVenues = Array.from(document.querySelectorAll('.venue-checkbox:checked')).map(cb => cb.value);
        const checkedOtherFields = Array.from(document.querySelectorAll('.other-checkbox:checked')).map(cb => cb.value);
        const searchQuery = searchBar.value.toLowerCase();

        // Get the minimum and maximum year from the range slider
        const minYear = parseInt(yearMinLabel.textContent);
        const maxYear = parseInt(yearMaxLabel.textContent);

        // Check the state of the "Textual" and "Graphical" checkboxes
        const isTextualChecked = textualCheckbox.checked;
        const isGraphicalChecked = graphicalCheckbox.checked;

        // Check the state of the "Annotation Generation" checkboxes
        const isManualChecked = manualCheckbox.checked;
        const isAutomaticChecked = automaticCheckbox.checked;
        const isSemiAutomaticChecked = semiAutomaticCheckbox.checked;

        // Log the state of the annotation generation checkboxes
        console.log(`Manual: ${isManualChecked}, Automatic: ${isAutomaticChecked}, Semi-Automatic: ${isSemiAutomaticChecked}`);

        // Filter the records based on selected filters, year range, search query, and annotation types
        filteredData = data.filter(record => {
            const recordVenue = record['Venue'];
            const recordYear = parseInt(record['Year']);
            const matchesYear = recordYear >= minYear && recordYear <= maxYear; // Filter by year range

            const matchesVenue = checkedVenues.includes(recordVenue);
            const matchesOtherVenue = checkedVenues.includes('Other') && otherVenues.includes(recordVenue);
            const matchesOtherFields = checkedOtherFields.some(field => record[field] === 'X');

            const title = record['Title'] ? record['Title'].toLowerCase() : '';
            const abstract = record['Abstract'] ? record['Abstract'].toLowerCase() : '';
            const authors = record['Authors'] ? record['Authors'].toLowerCase() : '';
            const matchesSearchQuery = title.includes(searchQuery) || abstract.includes(searchQuery) || authors.includes(searchQuery);

            // Filter by annotation types
            const annotationType = record['Annotation Types'] ? record['Annotation Types'].toLowerCase() : '';

            let matchesAnnotationType = true; // Default to true if no checkboxes are selected
            if (isTextualChecked && isGraphicalChecked) {
                matchesAnnotationType = annotationType.includes('textual') || annotationType.includes('graphical');
            } else if (isTextualChecked) {
                matchesAnnotationType = annotationType.includes('textual');
            } else if (isGraphicalChecked) {
                matchesAnnotationType = annotationType.includes('graphical');
            }

            // Filter by annotation generation method
            const annotationGenerationMethod = record['Annotation Generation Method'] ? record['Annotation Generation Method'].trim().toLowerCase() : '';
        
            // Log the annotation generation method for debugging
            console.log(`Annotation Generation Method: ${annotationGenerationMethod}`);

            let matchesAnnotationGeneration = true;
            if (isManualChecked || isAutomaticChecked || isSemiAutomaticChecked) {
                matchesAnnotationGeneration = (
                    (isManualChecked && annotationGenerationMethod.includes('manual')) || // Includes 'manual' anywhere
                    (isAutomaticChecked && annotationGenerationMethod === 'automatic') || // Exactly 'automatic'
                    (isSemiAutomaticChecked && annotationGenerationMethod === 'semi-automatic') // Exactly 'semi-automatic'
                );
            }

            return matchesYear && (matchesVenue || matchesOtherVenue) && matchesOtherFields && matchesSearchQuery && matchesAnnotationType && matchesAnnotationGeneration;
        });

        // Log the filtered data for debugging
        console.log('Filtered Data:', filteredData);

        renderCards(filteredData); // Render the filtered records
    }


    

    // Function to toggle dark mode with a smooth transition and update tooltip
    function toggleDarkMode() {
        const elements = document.querySelectorAll('.main-container, .filters-container, .content-container, #total-papers-container, #year-filter-container, #venue-filter-container, #other-filters-container, .filter-header, .card, .tag, .select-all-button, .triangle-button, #search-bar, .venue-filter, .other-filter, .abstract-div');

        elements.forEach(element => {
            element.classList.toggle('dark-mode');
        });

        const isDarkMode = document.body.classList.toggle('dark-mode');
        localStorage.setItem('darkMode', isDarkMode ? 'enabled' : 'disabled');

        // Update tooltip based on mode
        darkModeToggle.title = isDarkMode ? "Switch to Light Mode" : "Switch to Dark Mode";
    }

    // Function to play sound effects
    function playSound(sound) {
        sound.currentTime = 0;
        sound.play();
    }

    // Load dark mode preference from localStorage
    if (localStorage.getItem('darkMode') === 'enabled') {
        darkModeToggle.checked = true; // Check the toggle slider if dark mode was previously enabled
        toggleDarkMode();
    }
});
